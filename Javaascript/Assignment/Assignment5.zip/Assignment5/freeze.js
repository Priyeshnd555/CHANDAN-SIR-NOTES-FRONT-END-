const obj = {
  name: "Ankit",
  age: 25,
};
Object.freeze(obj);
obj.name = "AK";
obj.age = 100;
console.log(obj);

console.log("-----------------------------");
const obj2 = {
  id: 102,
  designation: "frontend developer",
  salary: 30000,
};
obj2.salary = 40000;
console.log(`data befor freeze: `, obj2);
Object.freeze(obj2);
obj2.id = 0;
console.log(`data after freeze: `, obj2);

console.log("-----------------------------");
const obj3 = [
  { name: "person1", age: 22 },
  { name: "person2", age: 33 },
  { name: "person3", age: 35 },
];
obj3[2].name = "personC";
console.log(`data before freeze: `, obj3);
Object.freeze(obj3);
obj3[1].name = "personB";

console.log(`data after freeze: `, obj3);
console.log("-----------------------------");
const obj4 = { place1: "Bangalre", place2: "Bhubaneswar", place3: "Ranchi" };
Object.freeze(obj4);
obj4.place1 = "Keral";
console.log(obj4);

console.log("-----------------------------");
const obj5 = { item1: "chair", item2: "table", item3: "bed", item4: "sofa" };
obj5.item4 = "Compuuter";
console.log(`before freeze: `, obj5);
Object.freeze(obj5);
obj5.item2 = "car";
console.log(`after freeze: `, obj5);
