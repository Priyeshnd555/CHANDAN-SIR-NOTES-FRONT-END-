const array1 =[7,2,5,[5,8],10];
console.log(array1.flat());

console.log("--------------------------");
const array2 =["string",false,[0,1,5],null]
console.log(array2.flat());

console.log("--------------------------");
const array3 = ["red","green",[12,13,["orange","red"],true],"yellow","white"]
const flat = array3.flat()
console.log(flat);

console.log("--------------------------");
const array4 = [11,22,[[[[90]]]],77,66]
console.log(array4.flat());

console.log("--------------------------");
const array5 = [{id:100},{id:200},[23,24,25,{id:500},{id:300},[1212,{id:600}]]]
const flat1 = array5.flat();
console.log(flat1);