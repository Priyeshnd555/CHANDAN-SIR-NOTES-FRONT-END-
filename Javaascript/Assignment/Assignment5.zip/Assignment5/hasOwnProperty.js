const fruits = ["Apple", "Banana", "Watermelon", "Orange"];
const test1 = fruits.hasOwnProperty(3);
const test2 = fruits.hasOwnProperty(4);
console.log(test1);
console.log(test2);

console.log("-------------------------------------------");
const obj ={}

const check1 = obj.hasOwnProperty('item');
console.log(check1);
obj.item = "mobile";
const check2 = obj.hasOwnProperty('item');
console.log(check2);

console.log("-------------------------------------------");
const array =[];
if(array.hasOwnProperty('index')){
    console.log("TRUE");
}
else{
    console.log("FALSE");
}
array[1] = "something";
if(array[1].hasOwnProperty('index')){
    console.log("TRUE");
}
else{
    console.log("FALSE");
}

console.log("-------------------------------------------");
const array3 =[11,22,33,44,55,66,77,88];
const check3 = array3.hasOwnProperty(5);
if(check3 === true){
    console.log("TRUE");
}
else{
    console.log("FALSE");
}

console.log("-------------------------------------------");
const arr = ['array1','array2','array3',100,200,300];
const check4 = arr.hasOwnProperty(-1);
console.log(check4);