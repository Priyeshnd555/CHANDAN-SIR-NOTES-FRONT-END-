const array1 = [1, 4, , 9, 3, 2, 10, 18, 15];
function checkk(num) {
  return num > 5;
}
const find = array1.findIndex(checkk); //it find only the first index of that value which fulfils the condition
console.log(find);

console.log("-------------------------------------");
const season = ["summer", "winter", "rainy", "autumn"];
function test(str) {
  return str.length > 5;
}
console.log(season.findIndex(test));

console.log("-------------------------------------");
const colors = ["red", "green", "yellow", "orange", "blue"];
function color(str) {
  return str.includes("n");
}
console.log(colors.findIndex(color));

console.log("-------------------------------------");
const array2 = [
  { id: 1, price: 100 },
  { id: 2, price: 500 },
  { id: 3, price: 550 },
];
function check2(findit){
    return array2.price>500;
}
const findI = array2.findIndex(check2);

console.log("-------------------------------------");
const array3 = ["string",111,null, {id:222,age:25},"hello"];
function test(t){
    return t === "hello"; 
}
console.log(array3.findIndex(test));