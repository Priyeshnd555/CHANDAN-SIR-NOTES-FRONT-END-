const object1 = {
  1: "somestring",
  2: 42,
  3: false,
};
const key1 = Object.keys(object1);
console.log(key1);

console.log("===============================");
const arr = ["name", "age", "skills"];
const key2 = Object.keys(arr);
console.log(key2);

console.log("===============================");
const anObj = { 100: "Ankit", 200: "Animesh", 300: "Alex" };
const key3 = Object.keys(anObj);
console.log(key3);

console.log("===============================");
const array = ["age1", "age2", "age3", "age4", "age5"];
const key4 = Object.keys(array);
console.log(key4);

console.log("===============================");
const obj5 = {
  name: "PersonA",
  height: "170cm",
  weight: 70,
};
const key5 = Object.keys(obj5);
console.log(key5);
