const str1 ="Hello World";
const reverse1 =str1.split("").reverse().join("");
console.log(reverse1);


console.log("---------------------------------");
const str2 = "Good Morning"
const reverse2 =str2.split("").reverse().join("");
console.log(reverse2);


console.log("---------------------------------");
const str3 = "Thank You"
const reverse3 =str3.split("").reverse().join("");
console.log(reverse3);



console.log("---------------------------------");
const str4 = "Test Yantra"
const reverse4 =str4.split("").reverse().join("");
console.log(reverse4);



console.log("---------------------------------");
const str5 = "September"
const reverse5 =str5.split("").reverse().join("");
console.log(reverse5);
