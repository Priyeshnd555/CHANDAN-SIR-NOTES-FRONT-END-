const array1 = [1, 4, , 9, 3, 2, 10, 18, 15];
function checkk(num) {
  return num > 5;
}
const find = array1.find(checkk); //it finds only the first item that fulfils the condition
console.log(find);

console.log("-------------------------------------");
const season = ["summer", "winter", "rainy", "autumn"];
function test(str) {
  return str.length > 5;
}
console.log(season.find(test));

console.log("-------------------------------------");
const colors = ["red", "green", "yellow", "orange", "blue"];
function color(str) {
  return str.includes("n");
}
console.log(colors.find(color));

console.log("-------------------------------------");
/* const obj1 = [
  { name: "sam", age: 24, married: false },
  { name: "smile", age: 19, married: false },
];
function obj(item) {
  return item.obj.name.length>3;
}
console.log(obj1.find(obj)); */

console.log("-------------------------------------");
const percentages =[65,70,80,59,77,95];
function topper(percent){
    return percent>70;
}
console.log(percentages.find(topper));
