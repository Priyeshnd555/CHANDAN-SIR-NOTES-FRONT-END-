const num1 = [100, 89, 45, 22, 34, 57, 69, 20];
console.log(`original array: `, num1);
const sort1 = num1.sort();
console.log(`sorted array: `, num1);

console.log("---------------------------------");
const num2 = [1,3,7,8,9,3,2,0];
console.log(`array: `,num2);
console.log(`sorted array:` ,num2.sort());

console.log("---------------------------------");
const num3 = [3,true,1,undefined,false,null,88,67];
console.log(`original array: `,num3);
const sort2 = num3.sort();
console.log(`sorted array: `,sort2);

console.log("---------------------------------");
const num4= ["sky","blue","rain","water","tree","wood"];
console.log(`before sorting:` ,num4);
console.log(`sorted array: `,num4.sort());

console.log("---------------------------------");
const num5 =["string",1212,undefined,null,333,[23,32,44,55],{title:"object1"},{title:"object2"},4000];
console.log(`before sorting: `,num5);
console.log(`after sorting: `,num5.sort());