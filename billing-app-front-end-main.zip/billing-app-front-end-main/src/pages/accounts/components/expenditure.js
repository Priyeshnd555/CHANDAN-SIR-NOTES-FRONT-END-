import React, { Component } from 'react'

export default class Expenditure extends Component {
    render() {
        return (
            <div>
                Expenditure
            </div>
        )
    }
}
