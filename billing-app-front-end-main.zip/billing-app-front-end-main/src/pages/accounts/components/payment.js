import React, { Component } from 'react'

export default class Payment extends Component {
    render() {
        return (
            <div>
                Payment
            </div>
        )
    }
}
