import React, { Component } from 'react'

export default class Investments extends Component {
    render() {
        return (
            <div>
                Investments
            </div>
        )
    }
}
