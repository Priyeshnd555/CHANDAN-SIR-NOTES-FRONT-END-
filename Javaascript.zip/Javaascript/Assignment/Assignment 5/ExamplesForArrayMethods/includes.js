const num = [23,235,23,34,5,78,]

const first = num.includes(0);
console.log(`num includes 0 : ${first}`);

const second = num.includes(23,2);
console.log(`num includes  23, from index 2: ${second}`);

const third = num.includes(235);
console.log(`num includes 235 : ${third}`);

const fourth = num.includes(23);
console.log(`num includes 23 : ${fourth}`);

const fifth = num.includes(34,2);
console.log(`num includes 34 : ${fifth}`);





