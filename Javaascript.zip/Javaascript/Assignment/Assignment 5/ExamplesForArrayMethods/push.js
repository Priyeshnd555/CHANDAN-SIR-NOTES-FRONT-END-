
/// push method 

const  num = [ 23,35,2,4,232,23,];

console.log(`original array ${num}`);

const first = num.push(2,3,4,);
console.log(`AFter push 1 : ${num}`);



const second  = num.push(74,3,4,)
console.log(`AFter push 3 : ${num}\n`);


const three = num.push(2757,3,4,)
console.log(`AFter push 3 : ${num}\n`);

const four = num.push(235,2)
console.log(`AFter push 4 : ${num}\n`);

const five = num.push(2,34,5,3)
console.log(`AFter push 5 : ${num}`);