const  num = [ 23,,6456,,788,232,124,5,]

console.log(`original array ${num}`);

const first =num.pop();
console.log(first);

const second =num.pop();
console.log(`${second} \n`);

const third=num.pop();
console.log(`${third} \n`);

const fourth =num.pop();
console.log(`${fourth} \n`);

const fifth =num.pop();
console.log(`${fifth} \n`);

console.log(`array after calling pop() :  [${num}]`);
