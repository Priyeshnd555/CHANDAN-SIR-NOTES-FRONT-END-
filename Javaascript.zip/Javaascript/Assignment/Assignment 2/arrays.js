
// first array
var a1 = [ 'array1', 243, , null, true, false, { name : 'KGF', year:2019}];

for(var i=0; i<a1.length;i++){

    console.log(` \n a1[${i}] = ${a1[i]} `);
}

// second array
var a1 = [ 'array1', 243, , null, true, false, { name : 'giri', age: 45,}];

for(var i=0; i<a1.length;i++){

    console.log(` \n a1[${i}] = ${a1[i]} `);
}

// third array
var a1 = [ 2345, null, , 'array3', true, false, { name : 'priyesh', age: 24}];

for(var i=0; i<a1.length;i++){

    console.log(` \n a1[${i}] = ${a1[i]} `);
}

// fourth array
var a1 = [ 'ar1', 243, , null, true, false, { value1 : 3545, value2: undefined, }];

for(var i=0; i<a1.length;i++){

    console.log(` \n a1[${i}] = ${a1[i]} `);
}

// fifth array
var a1 = [ 'null', 2343,null , ,true, false, { name : 'KetrF', year:null}];

for(var i=0; i<a1.length;i++){

    console.log(` \n a1[${i}] = ${a1[i]} `);
}