
var arr1 = new Array;

console.log(arr1);

var arr2 = new Array(8);
console.log(arr2);

var arr3 = new Array('array3', true, false, null, undefined,234);
console.log(arr3);

var arr4 = new Array(234, 34656.98895, undefined,null,);
console.log(arr4);

var arr5 = new Array(true, false)
console.log(arr5);

