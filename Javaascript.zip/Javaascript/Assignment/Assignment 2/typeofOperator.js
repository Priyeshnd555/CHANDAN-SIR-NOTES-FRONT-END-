

// null 

var a = null ;
var b = null ;
console.log(` \n type of a is : ${typeof a} \n type of b ${typeof b}`);

// undefined 

var aa;
var bb;
console.log(`\n type of aa : ${typeof aa} \n typeof b : ${typeof bb}`);

// string 

var aaa = 'hello';
var bbb = 'hi ';
console.log(` \n typeof aaa : ${typeof aaa} \n typeof bbb : ${typeof bbb}`);

// boolean 

var aboo = true;
var bboo = false;
console.log(` \n typeof aboo : ${typeof aboo} \n typeof bboo : ${typeof bboo}`);

// number 

var anum = 234;
var bnum = 234.353;
console.log(` \n typeof anum : ${typeof anum} \n typeof bnum : ${typeof bnum}`);

// symbol

var sym1 = Symbol();
var sym2 = Symbol('foo');
console.log(` \n typeof sym1 : ${typeof sym1} \n typeof sym2 : ${typeof sym2}`);






