

var tata = {

    color:'red',
    cost: 4500000,
    brand:'tata',
    Tax:'5%',
    finalCost : function (){
        return this.cost+this.Tax;
    },
};

    /* output of above object */
    console.log('object name :'+ tata.brand);
    
    console.log('tax :'+ tata.Ta);
    console.log('final cost : '+ tata.finalCost());
    console.log('\n');




var ferrari = {

    color:'red',
    cost: 500000,
    brand:'ferrari',
    Tax:'5%',
    finalCost :function(){
        return this.cost+this.Tax;
    },

};

 /* outp put of above object */
 console.log('object name :'+ ferrari.brand);
 console.log('cost :'+ ferrari.brand);
 console.log('tax :'+ ferrari.brand);
 console.log('final cost : '+ ferrari.finalCost());
 console.log('\n');




var bmw = {

    color:'red',
    cost: 3400000,
    brand:'bmw',
    Tax:'5%',
    finalCost : function (){
        return this.cost+this.Tax;
    }

};
  /* outp put of above object */
  console.log('object name :'+ bmw.brand);
  console.log('cost :'+ bmw.brand);
  console.log('tax :'+ bmw.brand);
  console.log('final cost : '+ bmw.finalCost());
  console.log('\n');

var rangeRover = {

    color:'red',
    cost:46500000,
    brand:'rangerover',
    Tax:'5%',
    finalCost : function (){
        return this.cost+this.Tax;
    }

};
 /* outp put of above object */
 console.log('object name :'+ rangeRover.brand);
 console.log('cost :'+ rangeRover.brand);
 console.log('tax :'+ rangeRover.brnd);
 console.log('final cost : '+ rangeRover.finalCost());
 console.log('\n');


var toyota = {

    color:'red',
    cost: 200000,
    brand:'toyata',
    Tax:'5%',
    finalCost : function (){
        return this.cost+this.Tax;
    }

};
 /* outp put of above object */
 console.log('object name :'+ toyota.brand);
 console.log('cost :'+ toyota.brand);
 console.log('tax :'+ toyota.brand);
 console.log('final cost : '+ toyota.finalCost());
 console.log('\n');
