var ferrari = new Object();

    ferrari.color='red';
    ferrari.cost= 500000;
    ferrari.brand='ferrari';
    ferrari.Tax='5%';
    
    ferrari.finalCost=function(){
        return this.cost+this.Tax;
    };
    
    /* output of above object */
    console.log('object name :'+ ferrari.brand);
   
    console.log('tax :'+ ferrari.Tax);
    console.log('final cost : '+ ferrari.finalCost());
    console.log('\n');
    
    
    var tata = new Object();

    tata.color='red';
    tata.cost= 500000;
    tata.brand='';
    tata.Tax='5%';

    tata.finalCost=function(){
        return this.cost+this.Tax;
    };

    /* outp put of above object */
    console.log('object name :'+ tata.brand);
    console.log('cost :'+ tata.brand);
    console.log('tax :'+ tata.Tax);
    console.log('final cost : '+ tata.finalCost());
    console.log('\n');

    var bmw = new Object();

        bmw.color='red';
        bmw.cost= 500000;
        bmw.brand='bmw';
        bmw.finalCost=function(){
        return this.cost+this.Tax;
    };

    /* outp put of above object */
    console.log('object name :'+ bmw.brand);
    console.log('cost :'+ bmw.brand);
    console.log('tax :'+ bmw.Tax);
    console.log('final cost : '+ bmw.finalCost());
    console.log('\n');

    var benz = new Object();

    benz.color='red';
    benz.cost= 500000;
    benz.brand='benz';
    benz.Tax='5%';
    benz.finalCost=function(){
        return this.cost+this.Tax;
    };

    /* outp put of above object */
    console.log('object name :'+ benz.brand);
    console.log('cost :'+ benz.brand);
    console.log('tax :'+ benz.Tax);
    console.log('final cost : '+ benz.finalCost());
    console.log('\n');


    var buggati = new Object();

    buggati.color='red';
    buggati.cost= 500000;
    buggati.brand='buggati';
    buggati.Tax='5%';
    buggati.finalCost=function(){
        return this.cost+this.Tax;
    };

    /* outp put of above object */
    console.log('object name :'+ buggati.brand);
    console.log('cost :'+ buggati.brand);
    console.log('tax :'+ buggati.Tax);
    console.log('final cost : '+ buggati.finalCost());
    console.log('\n');


    var suzuki = new Object();

    suzuki.color='red';
    suzuki.cost= 500000;
    suzuki.brand='suzuki';
    suzuki.Tax='5%';
    suzuki.finalCost=function(){
        return this.cost+this.Tax;
    };

    /* outp put of above object */
    console.log('object name :'+ suzuki.brand);
    console.log('cost :'+ suzuki.brand);
    console.log('tax :'+ suzuki.brand);
    console.log('final cost : '+ suzuki.finalCost());
    console.log('\n');


    var audi = new Object();

    audi.color='red';
    audi.cost= 500000;
    audi.brand='audi';
    audi.Tax='5%';
    audi.finalCost=function(){
        return this.cost+this.Tax;
    };

    /* outp put of above object */
    console.log('object name :'+ audi.brand);
    console.log('cost :'+ audi.brand);
    console.log('tax :'+ audi.brand);
    console.log('final cost : '+ audi.finalCost());
    console.log('\n');

