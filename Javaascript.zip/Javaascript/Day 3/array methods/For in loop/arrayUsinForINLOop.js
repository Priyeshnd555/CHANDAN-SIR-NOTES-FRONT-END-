var car= [ 'bmw', 'benz', 'toyota'];

for( var indoex in car){
    console.log(car[indoex]);
};

// here index is a variable we can use other nams instead of it 