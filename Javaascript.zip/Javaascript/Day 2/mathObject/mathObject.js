

console.log('-----------------------------\n');

console.log(Math.round(1.5));
console.log(Math.abs(-6));
console.log(Math.pow(2,3));
console.log(Math.sqrt(25));
console.log(Math.min(1,6));
console.log(Math.max(1,6));

console.log(Math.ceil(12.1));
console.log(Math.floor(12.9));
console.log(`\n random number between 1-100  : ${Math.ceil(Math.random()*100)}`);
// There  is chance the u may get no like 0.0034 so 
// the output will become zero so use 
// ceil it will automatically move to the next number
console.log();

console.log('\n')